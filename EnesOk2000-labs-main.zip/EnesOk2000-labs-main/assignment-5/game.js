class Card {
    constructor() {
        this.id = null;
        this.img = null;
        this.flipped = false;
        this.matched = false;
    }
}

class Game {
    constructor() {
        this.in_progress = true; //it should be false to begin with.
        this.winner = null;
        this.current_players_turn = Game.player_one;
        this.moves_made = 0;
         //new Array(16).fill().map( s => new Card() ); // null; n*n is what the size of the array should be.
        this.player_one_points = 0;
        this.player_two_points = 0;
        this.clicked_i = null;
        this.clicked_j = null;

        var array = this.return_array_of_cards();
        console.log(array);
        array = this.shuffle_array(array);
        console.log(array);

        this.cards = array;
    }

    /*
    start_game() {
        this.in_progress = true;
    }
    */

    /*
    get current_player() {
        return this.current_players_turn;
    }
    */

    return_array_of_cards(){
        var array_of_cards = new Array(16).fill().map( s => new Card() );
        for (var i = 0; i < 16; i++) {
            array_of_cards[i].id = i;
            if (i < 2) {array_of_cards[i].img = "banana.jpeg";}
            else if (i < 4) {array_of_cards[i].img = "potato.jpeg";}
            else if (i < 6) {array_of_cards[i].img = "carrot.jpg";}
            else if (i < 8) {array_of_cards[i].img = "grape.jpg";}
            else if (i < 10) {array_of_cards[i].img = "lemon.jpg";}
            else if (i < 12) {array_of_cards[i].img = "mushroom.jpeg";}
            else if (i < 14) {array_of_cards[i].img = "orange.jpg";}
            else {array_of_cards[i].img = "pear.jpg";}
        }
        return array_of_cards;
    }

// step 3: Create a function that shuffles the array of cards.
    shuffle_array(array_of_cards){
        var random_number = 0;
        var random_number_array = []
        var k = 0;
        while (random_number_array.length != array_of_cards.length) {
            random_number = Math.floor(Math.random() * array_of_cards.length); 
            if (!random_number_array.includes(random_number)){random_number_array.push(random_number);}
        }
        var new_array = []
        for (var i=0; i < array_of_cards.length; i++) {
            new_array.push(array_of_cards[random_number_array[i]])
        }
        // console.log("Ferdig!")
        return new_array;
    }

    flip(i) {
        if (!this.in_progress || this.cards[i].flipped) {
            console.log("Wrong flip.");
            return;
        }
        this.cards[i].flipped = true;
        this.moves_made++;
        //console.log(this.moves_made)
        //console.log(i)
        if (this.moves_made%2) { this.clicked_i = i; } 
        else {
            this.clicked_j = i;
            if (this.cards[this.clicked_i].img == this.cards[this.clicked_j].img) {
                this.cards[this.clicked_i].matched = true;
                this.cards[this.clicked_j].matched = true;
                //current_player = Game.current_player();
                if (this.current_players_turn == Game.player_one) {
                    this.player_one_points += 2; 
                    this.check_for_winner();
                    return;
                }
                this.player_two_points += 2;
                this.check_for_winner();
                return;
            }
            this.cards[this.clicked_i].flipped = false;
            this.cards[this.clicked_j].flipped = false;
            if (this.current_players_turn == Game.player_one) {
                this.current_players_turn = Game.player_two;
                return;
            }
            this.current_players_turn = Game.player_one;
            return;    
        }
            
    }

    /*
    flip(i, j) {
        if(i == j) {
            alert("You must flip two different cards! Try again!");
            return;
        }
        if (!this.in_progress) {
            alert("The game is not in progress! Start the game first!");
            return;
        }
        if (this.cards[i].flipped) {
            console.log("Card number ", i, " is already flipped! Try another card!");
            return;
        }
        if (this.cards[j].flipped) {
            console.log("Card number ", j, " is already flipped! Try another card!");
            return;
        }
        this.cards[i].flipped = true;
        this.cards[j].flipped = true;
        this.moves_made += 2;
        if (this.cards[i].img == this.cards[j].img) {
            this.cards[i].matched == true;
            this.cards[j].matched == true;
            //current_player = Game.current_player();
            if (this.current_players_turn == Game.player_one) {
                this.player_one_points += 2; 
                this.check_for_winner();
                return;
            }
            this.player_two_points += 2;
            this.check_for_winner();
            return;
        }
        this.cards[i].flipped = false;
        this.cards[j].flipped = false;
        if (this.current_players_turn == Game.player_one) {
            this.current_players_turn == Game.player_two;
            return;
        }
        this.current_players_turn == Game.player_one;
        return;        
    }
    */

    check_for_winner() {
        for (var k = 0; k < this.cards.length; k++) { //what if n is 5 and there is 1 card left. need to cover that case somehow.
            if (!this.cards[k].matched) {  
                console.log(this.cards[k]);
                // to fix the issue above, maybe make a counter and allow 1 card to be unmatched,
                // but if 2 cards are unmatched, leave then go into this if.
                console.log("All cards are not matched yet! Keep playing!");
                return;
            }
        }
        if (this.player_one_points > this.player_two_points) {
            this.winner = Game.player_one;
            this.in_progress = false;
            return;
        }
        else if (this.player_one_points < this.player_two_points) {
            this.winner = Game.player_two;
            this.in_progress = false;
            return;
        }
        this.in_progress = false;
        this.winner = "It's a tie!"
        return; 
    }
}

Game.player_one = "Player 1";
Game.player_two = "Player 2";
