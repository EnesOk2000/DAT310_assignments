class Card {
    constructor() {
        this.id = null;
        this.img = null;
        this.flipped = false;
        this.matched = false;
    }
}