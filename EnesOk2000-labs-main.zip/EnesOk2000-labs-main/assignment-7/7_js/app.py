"""
Assignment #7: AJAX
"""

from flask import Flask, request, g, render_template
import json

app = Flask(__name__)

class Albums():
    """Class representing a collection of albums."""

    def __init__(self, albums_file, tracks_file):
        self.__albums = {}
        self.__load_albums(albums_file)
        self.__load_tracks(tracks_file)

    def __load_albums(self, albums_file):
        """Loads a list of albums from a file."""
        list_albums = []
        print("loading albums...")
        with open(albums_file,'r') as file:
            for line in file:
                list_albums.append(line)
                #print(line)
                self.__albums[line] = []
        #print(list_albums)
        #print(self.__albums)
        return list_albums

    def __load_tracks(self, tracks_file):
        """Loads a list of tracks from a file."""
        list_tracks = []
        print("loading tracks...")
        list_keys = self.__albums.keys()
        #print(list_keys)
        for key in list_keys:
            self.__albums[key] = []
        with open(tracks_file,'r') as file:
            for line in file:
                #print(line[0])
                list_tracks.append(line)
                for key in list_keys:
                    if key[0] == line[0]:
                        correct_key=key
                value = self.__albums.get(correct_key) #list_keys[number]
                value.append(line)
                self.__albums[correct_key] = value
        #print(list_tracks)
        #print(self.__albums)
        return list_tracks

    def get_albums(self):
        """Returns a list of all albums, with album_id, artist and title."""
        albums_file = "data/albums.txt"
        print("getting albums...")
        #self.__load_tracks("data/tracks.txt")
        return self.__load_albums(albums_file)

    def get_album(self, album_id):
        print("getting one album...")
        """Returns all details of an album."""
        #list_tracks_for_one_album = []
        #with open('data/tracks.txt','r') as file:
        #    for line in file:
        #        #print(line[0])
        #        if line[0] == album_id:
        #            list_tracks_for_one_album.append(line)
        #print(list_tracks_for_one_album)
        #return list_tracks_for_one_album
        self.__load_tracks("data/tracks.txt")
        list_keys = self.__albums.keys()
        #print("Check")
        album_details = []
        for key in list_keys:
            if int(key[0]) == int(album_id):
                album_details.append(key)
                album_details.append(self.__albums.get(key))
                #print(self.__albums.get(key))
        #print(album_details)

        return album_details

    # This function/method is used to check that the property "albums" of the class "Albums" is properly configured.
    # The albums dict has contains keys which are the albums and values where each value is a list of all the songs in the album.
    def load(self):
        albums_file = "data/albums.txt"
        tracks_file = "data/tracks.txt"
        #print(self.__albums)
        return [self.__load_albums(albums_file), self.__load_tracks(tracks_file)]



# the Albums class is instantiated and stored in a config variable
# it's not the cleanest thing ever, but makes sure that the we load the text files only once
app.config["albums"] = Albums("data/albums.txt", "data/tracks.txt")

@app.route("/albums")
def albums():
    """Returns a list of albums (with album_id, author, and title) in JSON."""
    albums = app.config["albums"]
    the_list = albums.get_albums()
    # TODO complete (return albums.get_albums() in JSON format)
    json_format = json.dumps(the_list)
    return json_format

# This route is used to check that the property "albums" of the class "Albums" is properly configured.
# The albums dict has contains keys which are the albums and values where each value is a list of all the songs in the album.
@app.route("/new")
def new():
    albums = app.config["albums"]
    the_list = albums.load()
    json_format = json.dumps(the_list)
    return json_format

@app.route("/albuminfo", methods=["GET"])
def albuminfo():
    album_id = request.args.get("album_id", None)
    albums = app.config["albums"]
    #album_id = 3 # request.args.get("album_id", None)
    #if album_id: #album_id, True
    # TODO complete (return albums.get_album(album_id) in JSON format)
    the_list = albums.get_album(album_id)
    #print(the_list)
    json_format = json.dumps(the_list)
    return json_format
    #return "Wrong album id"

@app.route("/sample")
def sample():
    return app.send_static_file("index_static.html")

@app.route("/")
def index():
    return app.send_static_file("index.html")
    #return render_template("index.html", albums=app.config["albums"]) 
    # cannot do second argument since Albums is not an iterable object.

if __name__ == "__main__":
    app.run()
