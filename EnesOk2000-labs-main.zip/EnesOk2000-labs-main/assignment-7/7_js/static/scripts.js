/**
 * Assignment 7
 */

/** Load the list of albums */
async function listAlbums() {
    // TODO make an AJAX request to /albums
    // then populate the "albums_list" list with the results
    let req = await fetch("/albums");
    if (req.status == 200){
        let result = await req.text();
        result = JSON.parse(result);
		
        var album_id = 0;
        for (var i = 1; i < result.length+1; i++){
            var li = document.createElement("LI");
            var a = document.createElement("A");
			line_one = result[i-1];
			first = line_one.split('\t');
			//console.log(first);
			first = first[1] + " - " + first[2];
            a.innerHTML = first;
            a.href = "#";
            album_id = i.toString();
            li.id=album_id;
            li.onclick = find;
            // I tried really hard create an onclick event which executed showAlbums(i), but I ran into so many errors. 
            // The codline over made sure that I could get the correct album_id and that the event would occur.
            li.appendChild(a);
            document.getElementById("albums_list").appendChild(li);
        }
    }
}

function find() {
    showAlbum(this.id);
}

/** Show details of a given album */
async function showAlbum(album_id) {
    // TODO make an AJAX request to /albuminfo with the selected album_id as parameter (i.e., /albuminfo?album_id=xxx),
    // then show the album cover in the "album_cover" div and display the tracks in a table inside the "album_songs" div
    console.log(album_id);
    let url = "/albuminfo?album_id=" + album_id;
    let req = await fetch(url);
    if (req.status == 200){
        let result = await req.text();
        result = JSON.parse(result);
        //document.getElementById("album_info").innerHTML = result;
        //console.log(result);
        line_one = result[0];
        //console.log(line_one);
        first = line_one.split('\t');
        image_file = "/static/images/"+first[3];
		image_file = image_file.split('\n')[0];
        //console.log(image_file);
		var img = document.createElement("img");
		img.src = image_file;
		//console.log(img);
		document.getElementById("album_cover").removeChild(document.getElementById("album_cover").childNodes[0]);
		//console.log("Child removed");
		document.getElementById("album_cover").appendChild(img);
		//console.log(result[1]);
		var table = document.createElement("table");
		var tr = document.createElement("tr");
		var th1 = document.createElement("th");
		var th2 = document.createElement("th");
		var th3 = document.createElement("th");
		th1.innerHTML = "No.";
		th2.innerHTML = "Title";
		th3.innerHTML = "Length";
		tr.appendChild(th1);
		tr.appendChild(th2);
		tr.appendChild(th3);
		table.appendChild(tr);
		minute_count = 0;
		second_count = 0;
		for (var i = 1; i < result[1].length+1; i++){
			//console.log(i, result[1][i-1]);
			lol = result[1][i-1];
			lol = lol.split('\t');
			song_name = lol[1];
			song_duration = lol[2].split("\n")[0];
			minute_count = minute_count + parseInt(song_duration.split(":")[0]);
			second_count = second_count + parseInt(song_duration.split(":")[1]);
			//console.log(minute_count, ":", second_count);
			//console.log(i, song_name, song_duration);
			var new_tr = document.createElement("tr");
			var td1 = document.createElement("td");
			var td2 = document.createElement("td");
			var td3 = document.createElement("td");
			td1.innerHTML = i.toString()+".";
			td2.innerHTML = song_name;
			td3.innerHTML = song_duration;
			new_tr.appendChild(td1);
			new_tr.appendChild(td2);
			new_tr.appendChild(td3);
			table.appendChild(new_tr);
		}
		second_count_to_minute = parseInt(parseInt(second_count)/60);
		second_count = second_count - second_count_to_minute*60;
		minute_count = minute_count + second_count_to_minute;
		//console.log(minute_count, ":", second_count);
		if (second_count < 10){
			second_count = "0"+second_count.toString();
			//console.log("OOOOOOO", second_count);
		}
		var total_tr = document.createElement("tr");
		var total_td1 = document.createElement("td");
		var total_td2 = document.createElement("td");
		var total_strong1 = document.createElement("strong");
		var total_strong2 = document.createElement("strong");
		total_td1.colSpan = 2;
		total_strong1.innerHTML = "Total length:";
		total_strong2.innerHTML = minute_count.toString()+":"+second_count.toString();
		total_td1.appendChild(total_strong1);
		total_td2.appendChild(total_strong2);
		total_tr.appendChild(total_td1);
		total_tr.appendChild(total_td2);
		table.appendChild(total_tr);
		document.getElementById("album_songs").removeChild(document.getElementById("album_songs").childNodes[0]);
		document.getElementById("album_songs").appendChild(table);
    }
}
