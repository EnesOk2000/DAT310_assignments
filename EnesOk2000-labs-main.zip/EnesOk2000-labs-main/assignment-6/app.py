"""
Flask: Using templates
"""

from setup_db import *
import sqlite3, random
from flask import Flask, render_template, request, redirect, url_for, g

app = Flask(__name__)

DATABASE = './database.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


@app.route("/")
def index():
    # get the database connection
    conn = get_db()
    return render_template("index.html", courses=select_courses(conn), students=select_students(conn))
    # select_students executes SELECT SQL statement on database connetion returns list of students

# Add additional routes here.

@app.route("/student/<int:student_no>")
def student(student_no):
    conn = get_db()
    return render_template('student.html', student_no = student_no, students=select_students(conn), grades=select_grades(conn))

@app.route("/course/<string:course_code>")
def course(course_code):
    conn = get_db()
    return render_template('course.html', course_code = course_code, 
    courses=select_courses(conn), grades=select_grades(conn),students=select_students(conn))

@app.route("/add_student", methods = ["GET", "POST"])
def app_add_student():
    conn = get_db()
    text = ""
    students=select_students(conn)
    if request.method == "POST":
        student_no = random.randint(100000, 999999)
        while student_no in students:
            student_no = random.randint(100000, 999999)
        name = request.form["name"]
        if name != "":
            # text = "Student added successfully!"
            add_student(conn, student_no, name)
            return redirect(url_for('index'))
        else:
            text = "No name entered. Try again!"
    return render_template('add_student.html', text=text, students=students)

@app.route("/add_grade", methods = ["GET", "POST"])
def app_add_grade():
    conn = get_db()
    text = ""
    if request.method == "POST":
        cid = request.form["course"]
        stud = request.form["stud"]
        grade_grade = request.form["grade"]
        if cid != "" and stud != "" and grade_grade != "":
            text = "Grade successfully added!"
            add_grade(conn, cid, stud, grade_grade)
        else:
            text = "You need to select a course, a student and a grade. Try again!"
    return render_template('add_grade.html', text=text, courses=select_courses(conn), students=select_students(conn))

if __name__ == "__main__":
    app.run(debug=True)