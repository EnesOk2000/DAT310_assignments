"use strict";

window.onload=oppstart;

function oppstart() {
    document.getElementById("btn_add").onclick=skriv;
}

function skriv() {
    
    class Entry {
        constructor(name, tel, email) {
          this.name = name;
          this.tel = tel;
          this.email = email;
        }
    }
    
    //let entry1 = new Entry("Enes", "2222 5555", "enes@live.no");

    let txt_name_value = document.getElementById("txt_name").value;
    let txt_tel_value = document.getElementById("txt_tel").value;
    let txt_email_value = document.getElementById("txt_email").value;
    let entry2 = new Entry(txt_name_value, txt_tel_value, txt_email_value);
    //document.write(entry1.name);
    

    //document.body.style.backgroundColor="red";

    
    let nyDiv = document.createElement("div");
    let nyttInnhold = document.createTextNode(entry2.name, txt_tel_value, txt_email_value);
    nyDiv.appendChild(nyttInnhold);
    let naaDiv = document.getElementById("magiske_diver");
    document.body.insertBefore(nyDiv, naaDiv);
    
}
